python demonstrations_to_prompts.py --input_demonstrations "./demonstrations/race/hate_black_sentences.txt" --output_file "test_prompts.txt"
